package com.tecmilenio.actividad3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.view.GestureDetectorCompat;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * Esta es la app correspondiente a la actividad del tema 3 del curso
 * Desarrollo de aplicaciones en plataforma Android
 * Nombre: Gerardo Valenzuela
 * id al02848557
 * fecha 28/08/2019
 *
 * en esta aplicacion al ejecutarse ya sea un gesto o un evento
 * se presentara el nombre del evento en la etiqueta de texto
 * y el color de fondo de la app cambiara de color, conforme al
 * siguiente listado:
 *      Evento                  Color
 *      onClick                 Gris claro
 *      onSingleTapConfirmed    Blanco
 *      onDoubleTap             Azul
 *      onDoubleTapEvent        Negro
 *      onDown                  Verde
 *      onShowPress             Rojo
 *      onSingleTapUp           Magenta
 *      onScroll                Amarillo
 *      onLongPress             Gris
 *      onFling                 Gris Oscuro
 *
 * @author Gerardo Valenzuela (al02848557@tecmilenio.mx)
 */
public class MainActivity extends AppCompatActivity implements GestureDetector.OnGestureListener, GestureDetector.OnDoubleTapListener, View.OnClickListener {

    private GestureDetectorCompat gestureDetector;
    private ConstraintLayout layout;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        layout = findViewById(R.id.layout);
        textView = findViewById(R.id.text_view);

        Button button = findViewById(R.id.button);
        button.setOnClickListener(this);

        gestureDetector = new GestureDetectorCompat(this, this);
        gestureDetector.setOnDoubleTapListener(this);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        // Es importante interceptar los eventos de touch para manipularlos en nuestra app
        gestureDetector.onTouchEvent(event);

        return super.onTouchEvent(event);
    }

    @Override
    public void onClick(View view) {
        textView.setText(getString(R.string.event, "onClick"));
        // Al dar click en el botón, la pantalla va a cambiar a gris calor.
        layout.setBackgroundColor(Color.LTGRAY);
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
        textView.setText(getString(R.string.event, "onSingleTapConfirmed"));
        layout.setBackgroundColor(Color.WHITE);
        return false;
    }

    @Override
    public boolean onDoubleTap(MotionEvent motionEvent) {
        textView.setText(getString(R.string.event, "onDoubleTap"));
        layout.setBackgroundColor(Color.BLUE);
        return false;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent motionEvent) {
        textView.setText(getString(R.string.event, "onDoubleTapEvent"));
        layout.setBackgroundColor(Color.BLACK);

        return false;
    }

    @Override
    public boolean onDown(MotionEvent motionEvent) {
        textView.setText(getString(R.string.event, "onDown"));
        layout.setBackgroundColor(Color.GREEN);

        return false;
    }

    @Override
    public void onShowPress(MotionEvent motionEvent) {
        textView.setText(getString(R.string.event, "onShowPress"));
        layout.setBackgroundColor(Color.RED);

    }

    @Override
    public boolean onSingleTapUp(MotionEvent motionEvent) {
        textView.setText(getString(R.string.event, "onSingleTapUp"));
        layout.setBackgroundColor(Color.MAGENTA);

        return false;
    }

    @Override
    public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
        textView.setText(getString(R.string.event, "onScroll"));
        layout.setBackgroundColor(Color.YELLOW);

        return false;
    }

    @Override
    public void onLongPress(MotionEvent motionEvent) {
        textView.setText(getString(R.string.event, "onLongPress"));
        layout.setBackgroundColor(Color.GRAY);

    }

    @Override
    public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
        textView.setText(getString(R.string.event, "onFling"));
        layout.setBackgroundColor(Color.DKGRAY);

        return false;
    }
}

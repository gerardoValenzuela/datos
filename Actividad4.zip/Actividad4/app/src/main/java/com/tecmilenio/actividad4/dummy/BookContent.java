package com.tecmilenio.actividad4.dummy;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Helper class for providing sample content for user interfaces created by
 * Android template wizards.
 */
public class BookContent {

    /**
     * An array of sample (dummy) items.
     */
    public static final List<BookItem> ITEMS = new ArrayList<>();

    // TODO: Aquí hay que agregar el título de los libros que van a aparecer en la lista.
    /**
     * An array of sample (dummy) titles.
     */
    public static final List<String> TITLES = new ArrayList<String>() {
        {
            add("Android App Development for Dummies");
            add("Android Programming: The Big Nerd Ranch Guide");
            add("Professional Android");
        }
    };

    // TODO: Aquí hay que agregar la url de los libros que va a aparecer en el detalle.
    /**
     * An array of sample (dummy) urls.
     */
    public static final List<String> URLS = new ArrayList<String>() {
        {
            add("https://www.amazon.com.mx/Android-Development-Dummies-Michael-Burton/dp/1119017920/ref=sr_1_2?__mk_es_MX=%C3%85M%C3%85%C5%BD%C3%95%C3%91&keywords=android+book&qid=1567621051&s=gateway&sr=8-2");
            add("https://www.amazon.com.mx/Android-Programming-Nerd-Ranch-Guide/dp/0134706056/ref=sr_1_3?__mk_es_MX=%C3%85M%C3%85%C5%BD%C3%95%C3%91&keywords=android+book&qid=1567621051&s=gateway&sr=8-3");
            add("https://www.amazon.com.mx/Professional-Android-Reto-Meier/dp/1118949528/ref=sr_1_4?__mk_es_MX=%C3%85M%C3%85%C5%BD%C3%95%C3%91&keywords=android+book&qid=1567621051&s=gateway&sr=8-4");
        }
    };

    /**
     * A map of sample (dummy) items, by ID.
     */
    public static final Map<String, BookItem> ITEM_MAP = new HashMap<>();

    private static final int COUNT = 7;

    static {
        // Add some sample items.
        for (int i = 0; i < COUNT; i++) {
            addItem(createDummyItem(i));
        }
    }

    private static void addItem(BookItem item) {
        ITEMS.add(item);
        ITEM_MAP.put(item.id, item);
    }

    private static BookItem createDummyItem(int position) {
        return new BookItem(String.valueOf(position + 1), TITLES.get(position), URLS.get(position));
    }

    /**
     * A dummy item representing a piece of content.
     */
    public static class BookItem {
        public final String id;
        final String title;
        final String url;

        BookItem(String id, String title, String url) {
            this.id = id;
            this.title = title;
            this.url = url;
        }

        public String getTitle() {
            return title;
        }

        public String getUrl() {
            return url;
        }

        @Override
        public String toString() {
            return title;
        }
    }
}
